from odoo import models, fields, api


class Session(models.Model):
    _name= "clinicraquel.session"
    _description = "clinicraquel.session"

    id = fields.Integer()
    name = fields.Char(required = True, string="Nombre")
    description = fields.Text(string="Descripción")
    date = fields.Date(string="Fecha")

   
    treatment = fields.Many2one("clinicraquel.treatment", ondelete = "CASCADE", string="Tratamientos")
    techniques = fields.Many2many("clinicraquel.technique", relation = "technique_session", column1="techniques", column2="sessions", string="Técnicas")
    professional = fields.Many2one("clinicraquel.professional", ondelete="CASCADE", string="Profesional", readonly=True)
    

    def _get_professional(self):
        for session in self:
            session.professional = session.treatment.professional