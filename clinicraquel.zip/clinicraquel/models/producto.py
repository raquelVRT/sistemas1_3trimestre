from odoo import models, fields, api

class Producto(models.Model):
    _name = "clinicraquel.producto"
    _description = "Producto"

    name = fields.Char(string="Nombre")
    descripcion = fields.Text(string="Descripción")
    cantidad_necesaria = fields.Integer(string="Cantidad Necesaria")
    proveedor = fields.Char(string="Proveedor")
    contacto = fields.Char(string="Contacto")
    existencias_actuales = fields.Integer(string="Existencias Actuales", default=0)
    existencias_necesarias = fields.Integer(string="Existencias Necesarias", default=0)