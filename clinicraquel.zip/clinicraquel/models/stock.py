from odoo import models, fields, api

class Stock(models.Model):
    _name = "clinicraquel.stock"
    _inherit = "clinicraquel.producto"
    _description = "Stock"

    # Atributos adicionales para la clase de Stock
    stock_id = fields.Char(string="ID de Stock")
  