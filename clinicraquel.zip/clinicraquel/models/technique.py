from odoo import models, fields, api


class Technique(models.Model):
    _name= "clinicraquel.technique"
    _description = "clinicraquel.technique"

    id = fields.Integer()
    name = fields.Char(string="Nombre")
    description = fields.Text(string="Descripción")

    
    sessions = fields.Many2many("clinicraquel.session", relation = "technique_session", column1="sessions", column2="techniques", string="Sesiones")