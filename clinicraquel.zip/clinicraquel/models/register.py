from odoo import models, fields, api


class Register(models.Model):
    _name= "clinicraquel.register"
    _description = "clinicraquel.register"

    id = fields.Integer()
    name = fields.Char(string="Nombre")
    description = fields.Text(string="Descripción")

    

    client = fields.Many2one("clinicraquel.client", ondelete="CASCADE", string="Cliente")


    treatments = fields.One2many(comodel_name="clinicraquel.treatment", inverse_name = "register", string="Tratamientos")