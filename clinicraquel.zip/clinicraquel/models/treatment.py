from odoo import models, fields, api


class Treatment(models.Model):
    _name= "clinicraquel.treatment"
    _description = "clinicraquel.treatment"

    id = fields.Integer()
    name = fields.Char(required = True, string="Nombre", compute = "_get_name")
    description = fields.Text(string="Descripción")
    initdate = fields.Datetime(string="Fecha de Inicio")
    enddate = fields.Datetime(string="Fecha de Fin")


    register = fields.Many2one("clinicraquel.register", ondelete = "CASCADE", string="Registro")
    sessions = fields.One2many(comodel_name="clinicraquel.session", inverse_name = "treatment", readonly = True, string="Sesiones")
    professional = fields.Many2one("clinicraquel.professional", ondelete = "CASCADE", string="Profesional")


    @api.depends("register") 
    def _get_name(self): 
        for treatment in self: 
            if treatment.register: 
               treatment.name = f"{treatment.register.client.name} - {treatment.register.name}" 
            else: 
                treatment.name = False

