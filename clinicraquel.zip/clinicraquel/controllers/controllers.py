# -*- coding: utf-8 -*-
# from odoo import http


# class Clinicraquel(http.Controller):
#     @http.route('/clinicraquel/clinicraquel', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/clinicraquel/clinicraquel/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('clinicraquel.listing', {
#             'root': '/clinicraquel/clinicraquel',
#             'objects': http.request.env['clinicraquel.clinicraquel'].search([]),
#         })

#     @http.route('/clinicraquel/clinicraquel/objects/<model("clinicraquel.clinicraquel"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('clinicraquel.object', {
#             'object': obj
#         })

